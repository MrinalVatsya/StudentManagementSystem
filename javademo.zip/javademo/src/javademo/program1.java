package javademo;//Demo of ArrayList and its various functions.
import java.util.*;
public class program1 {
	public static void main(String args[])
	{
		int i;
	ArrayList<Integer> arr = new ArrayList<Integer>(4);//Dynamic array created
	for(i=0;i<4;i++)//adding element one by one
		arr.add(i+1);
	
	//arr.remove(2); remove element at a particular index
//	for(i=0;i<4;i++)
//	    System.out.print(arr.get(i)+ " ");//get() function ...
	
	Object[] array = arr.toArray();
	for(Object x : array)//converting arraylist to array
	{		
//		System.out.print(x+ " ");
	}
//		System.out.println(array[0]);//now arraylist is converted to array .
		//USING ITERATOR IN JAVA
		Iterator it = arr.iterator();
		int sum = 0;
		Integer x;
		//find sum of array 
		while(it.hasNext())
		{
			x = (Integer)it.next();
//			it = (Iterator) it.next();
			sum += x;
			//System.out.println(x);
		}
		System.out.println(sum);
	}
}
